<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Data User</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data User</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

<section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-8 col-6">
            <!-- small box -->
             <div class="card card-primary elevation-4">
              <div class="card-header">
                <h3 class="card-title"><b>Form Edit Data User<b></h3>

                <div class="card-tools float-right">
                <a href="<?php echo base_url('user'); ?>" class="btn btn-tool">
                  <i class="fas fa-times"></i>
                </a>
              </div>
             </div>

        <?php
        foreach ($user as $i) :
        ?>
        
         <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url()."user/update_data_user"; ?>">
                <div class="card-body">

                  <input type="hidden" name="old_key" value="<?php echo $i->username; ?>">

                  <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="text" name="username" value="<?php echo $i->username; ?>" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" readonly>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="text" name="password" value="<?php echo $i->password; ?>" class="form-control" id="exampleInputPassword1" placeholder="Enter Password" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Level</label>
                  <select name="level" class="form-control" id="exampleInputPassword1">
                    
                   <option value="Admin" <?php if($i->level == 'Admin') {echo "selected";} ?>>Admin</option>

                   <option value="Operator" <?php if($i->level == 'Operator') {echo "selected";} ?>>Operator</option>

                   <option value="User" <?php if($i->level == 'User') {echo "selected";} ?>>User</option>

                  </select>
                  </div>
                </div>
                <!-- /.card-body -->

                  <div class="card-footer">
                    <button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>   Delete</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i>   Save</button>
                  </div>
              </form>

              <?php endforeach; ?>

             </div>
            </div>
           </div>
          </section>

<!----------------------DEFAULT MODAL ADD USER DATA---------------------------------->
      <div class="modal fade" id="modal-default">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title"><b>Form Add Data User</b></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
<!------------------------------batas kode sebelumnya----------------------->

          </div>
        </div>
      </div>
    </div>
  </div>