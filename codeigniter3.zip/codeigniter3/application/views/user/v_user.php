<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Data User</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data User</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

<section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-8 col-6">
            <!-- small box -->
             <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add User</button>

             <br><br>

            <table class="table">
        <tr>
            <th>Nomor</th>
            <th>Username</th>
            <th>Password</th>
            <th>Level</th>
            <th colspan="2">Action</th>
        </tr>

        <?php $no=1;
        foreach ($user as $i) : 
        ?>

        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $i->username; ?></td>
            <td><?php echo $i->password; ?></td>
            <td><?php echo $i->level;    ?></td>
            <td onclick="javascript: return confirm ('Do you sure want to delete this data?')"><?php echo anchor("user/hapus_data_user/".$i->username,'<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>  Delete</div>') ?> </td>
            <td><?php echo anchor("user/edit_data_user/".$i->username,'<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>  Edit</div>') ?> </td>
        </tr>

        <?php $no++;
        endforeach;  
        ?>

    </table>
             </div>
            </div>
           </div>
          </section>

<!----------------------DEFAULT MODAL ADD USER DATA---------------------------------->
      <div class="modal fade" id="modal-default">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title"><b>Form Add Data User</b></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
<!------------------------------batas kode sebelumnya----------------------->


                  <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url()."user/tambah_data_user"; ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="text" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Level</label>

                  <select name="level" class="form-control" id="exampleInputPassword1">
                   <option>Admin</option>
                   <option>Operator</option>
                   <option>User</option>
                  </select>
                  </div>
                </div>
                <!-- /.card-body -->

                  <div class="modal-footer">
                    <button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>   Delete</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i>   Save</button>
                  </div>
              </form>
          </div>
        </div>
      </div>
    </div>
  </div>