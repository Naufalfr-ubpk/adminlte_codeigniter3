<!DOCTYPE html>
<html>
    <head>
        <title>Login2</title>
    </head>
    <body>
        <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam hendrerit, nibh quis semper hendrerit, metus ipsum tincidunt lacus, sit amet mollis ante nisl vulputate augue. Donec vehicula nibh a sodales faucibus. Suspendisse dolor elit, dapibus eu ultricies at, tincidunt vitae purus. Nulla rutrum aliquet nibh, ac porta risus ullamcorper quis. Fusce sit amet facilisis mi. Aenean volutpat fringilla mauris, non euismod magna faucibus non. Integer a pharetra ante. Etiam venenatis turpis sed erat laoreet convallis. Mauris vestibulum luctus tortor, sed finibus nulla mollis quis. Duis finibus leo magna, et venenatis mi auctor eget. Aliquam erat volutpat. Suspendisse quis mi sit amet nibh posuere viverra in at ex. Maecenas faucibus tincidunt nisi ac cursus. Cras sed tellus at tortor pretium efficitur.</h2>
    </body>
</html>