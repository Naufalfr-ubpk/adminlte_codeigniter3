<?php

class Auth extends CI_Controller
{
    public function index ()
    {
        $this->load->view("v_login");
    }

    public function index2 ()
    {
        $this->load->view("v_login2");
    }
}
?>