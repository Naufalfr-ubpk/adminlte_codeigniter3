<?php
class User extends CI_Controller
{
    public function index()
    {
        $this->load->model("model_user");
        $data["user"] = $this->model_user->tampil_user()->result();

        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view("user/v_user", $data);
		$this->load->view('templates/footer');
    }

    public function tambah_data_user()
    {

        $this->load->model("model_user");

        $username = $this->input->post("username");
        $password = $this->input->post("password");
        $level    = $this->input->post("level");

        $data = array(

            "username" => $username,
            "password" => $password,
            "level"    => $level,
        );

        $this->model_user->tambah_data_user($data, "tb_user");

        redirect("user");
    }

    public function hapus_data_user ($username)
    {

        $where = array ("username" => $username);
        $this->model_user->hapus_data_user($where, "tb_user");
        redirect("user");
    }

    public function edit_data_user ($username)
    {
        $where = array ("username" => $username);
        $data ["user"] = $this->model_user->edit_data_user("tb_user", $where)->result();
        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view("user/f_edit", $data);
		$this->load->view('templates/footer');

    }

    public function update_data_user ()
    {
        $key    = $this->input->post('old_key');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $level    = $this->input->post('level');

        $data = array(
            'username' => $username,
            'password' => $password,
            'level'    => $level
        );

        $where = array(
            'username' => $key
        );

        $this->model_user->update_data_user($where, $data, 'tb_user');
        redirect('user');
    }

}
?>